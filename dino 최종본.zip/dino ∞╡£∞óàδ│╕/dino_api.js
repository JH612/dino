const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");

let score1; // 플레이어 1의 현재 점수
let score2; // 플레이어 2의 현재 점수
let scoreText1; //현재 점수 텍스트
let highscore1; //최고 점수
let scoreText2; //현재 점수 텍스트
let highscore2; //최고 점수
let highscoreText1; //최고 점수 텍스트
let highscoreText2; //최고 점수 텍스트
let dino1; // 플레이어 1의 공룡
let dino2; // 플레이어 2의 공룡
let gravity; //중력값
let obstacles = []; //장애물
let gameSpeed; //게임 속도
let keys1 = {}; // 플레이어 1의 키 값
let keys2 = {}; // 플레이어 2의 키 값

let dinoimgis=["dino_clear","dino_rainy","dino_snowy","dino_cloudy","dino_stormy"];
let downimgs=["dinodown_clear","dinodown_rainy","dinodown_snowy","dinodown_cloudy","dinodown_stormy"];
let obstaclleimgs=["bug_clear","sun_clear","clouds_cloudy","cloude_cloudy","rain_rainy","pool_rainy","snow_snowy","snowman_snowy","thunder_stormy"];

let dinoimg=["",""]; //공룡의 직접 들어갈 이미지가 정해짐start에서
let obstacleimg=["",""];//장애불이 직접 들어갈 이미지가 정해짐 startㅇ서

let dinoweather; //api로 가져올 날씨->start에서 한번 반영된다

let tempSeoul = 0; //서울의 기온 변수

//이벤트 리스너 추가
document.addEventListener("keydown", function (evt) {
  if (evt.keyCode === 87) keys1["W"] = true; // W 키 (플레이어 1)
  if (evt.keyCode === 83) keys1["S"] = true; // S 키 (플레이어 1)
  if (evt.keyCode === 38) keys2["UP"] = true; // 화살표 위 키 (플레이어 2)
  if (evt.keyCode === 40) keys2["DOWN"] = true; // 화살표 아래 키 (플레이어 2)
});
document.addEventListener("keyup", function (evt) {
  if (evt.keyCode === 87) keys1["W"] = false;
  if (evt.keyCode === 83) keys1["S"] = false;
  if (evt.keyCode === 38) keys2["UP"] = false;
  if (evt.keyCode === 40) keys2["DOWN"] = false;
});

class Dino {
  constructor(x, y, w, h, c, player) {
    this.x = x; //x좌표
    this.y = y; //y좌표
    this.w = w; //공룡 너비
    this.h = h; //공룡 높이
    this.c = c; //히트박스 color
    this.player = player;

    this.dy = 0; //점프할 때 쓸 변수
    this.jumpForce = 30;
    this.originalHeight = this.h; //숙이기 전 높이
    this.grounded = false; //땅에 있는지 판단
    this.jumpTimer = 0; //점프 시간 체크를 위한 타이머 추가
  }

  Draw() {

    console.log(dinoimg)
    var img = new Image();
    if ((keys1["S"] || keys1["DOWN"]) && this.grounded) {
      //img.src = "dino_down.png";
      img.src =dinoimg[1];
      ctx.drawImage(img, this.x, this.y, this.w, this.h);
    } else {
      /*if(tempSeoul<15){
        img.src = 'santa_dino_up.png'
        ctx.drawImage(img,this.x,this.y,this.w,this.h); 안씀
      }else*/ 
      {
       // img.src = "dino_up.png";
       img.src=dinoimg[0];
        ctx.drawImage(img, this.x, this.y, this.w, this.h);
      }
    }
  }

  
  Jump() {
    //점프함수 추가
    //animate()에서 키 입력 받을 예정
    // -> 키 입력 받아서 점프
    // 점프 시간 계산을 위한 타이머 변수 추가함
    //땅에 있고 타이머 == 0 이면 Jump()를 생성

    if (this.grounded && this.jumpTimer == 0) {
      //땅에 있는지 && 타이머 = 0
      this.jumpTimer = 1;
      this.dy = -this.jumpForce;
    } else if (this.jumpTimer > 0 && this.jumpTimer < 15) {
      this.jumpTimer++;
      this.dy = -this.jumpForce - this.jumpTimer / 50; //갈수록 빠르게 떨어지는 것 구현
    }
  }

  Animate() {
    if (this.player === 1) {
      if (keys1["W"] && this.grounded) {
        this.Jump();
      } else {
        this.jumpTimer = 0;
      }

      if (keys1["S"] && this.grounded) {
        if (this.h !== this.originalHeight / 2) {
          this.y += this.h / 2;
          this.h = this.originalHeight / 2;
        }
      } else {
        if (this.h !== this.originalHeight) {
          this.h = this.originalHeight;
          this.y -= this.h / 2;
        }
      }
    }

    else if (this.player === 2) {
      if (keys2["UP"] && this.grounded) {
        this.Jump();
      } else {
        this.jumpTimer = 0;
      }

      if (keys2["DOWN"] && this.grounded) {
        if (this.h !== this.originalHeight / 2) {
          this.y += this.h / 2;
          this.h = this.originalHeight / 2;
        }
      } else {
        if (this.h !== this.originalHeight) {
          this.h = this.originalHeight;
          this.y -= this.h / 2;
        }
      }
    }

    this.y += this.dy;

    if (this.y + this.h < canvas.height) {
      this.dy += gravity;
      this.grounded = false;
    } else {
      this.dy = 0;
      this.grounded = true;
      this.y = canvas.height - this.h; // Y 좌표를 바닥에 붙임
    }

    this.Draw();
  }
}


const getJSON = function(url, callback){
  const xhr = new XMLHttpRequest();
  xhr.open('GET', url, true);
  xhr.responseType = 'json';
  xhr.onload = function(){
    const status = xhr.status;
    if(status === 200){
      callback(null, xhr.response);
    } else{
      callback(status, xhr.response);
    }
  };
  xhr.send();
};


class Obstacle {
  constructor(x, y, w, h, c) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.c = c;

    this.dx = -gameSpeed; //왼쪽으로 달려올 예정
    this.isBird = false;
  }

  Update() {
    //darw해주고 x좌표 갱신해줄 예정
    this.x += this.dx;
    this.Draw();
    this.dx = -gameSpeed;
  }

  Draw() {
    ////히트박스 판정을 위해 네모 그려줌
    //ctx.beginPath();
    //ctx.fillStyle = this.c;
    //ctx.fillRect(this.x, this.y, this.w, this.h);
    //ctx.closePath();

    var img = new Image();
    if (this.isBird == true) {
      img.src = obstacleimg[0];
      ctx.drawImage(img, this.x, this.y, this.w, this.h);
    } else {
      img.src = obstacleimg[1];
      ctx.drawImage(img, this.x, this.y, this.w, this.h);
    }
  }
}

class Text {
  constructor(t, x, y, a, c, s) {
    this.t = t;
    this.x = x;
    this.y = y;
    this.a = a;
    this.c = c;
    this.s = s;
  }

  Draw() {
    ctx.beginPath();
    ctx.fillStyle = this.c;
    ctx.font = this.s + "px sans-serif";
    ctx.textAlign = this.a;
    ctx.fillText(this.t, this.x, this.y);
    ctx.closePath();
  }
}
function SpawnObstacle() {
  let size = RandomIntInRange(20, 70); //20~70 정수 랜덤 생성, 사이즈를 20~70으로 랜덤으로 적용
  let type = RandomIntInRange(0, 1); //0~1 정수 랜덤 생성, 0 = 선인장, 1 = 새 장애물 생성
  let obstacle = new Obstacle(
    canvas.width + size,
    canvas.height - size,
    size,
    size,
    "#2484E4"
  );

  if (type == 1) {
    obstacle.y -= dino.originalHeight - 10; //새는 공룡 키보다 10만큼 낮게 날게 만들어줌
    obstacle.isBird = true;
  }
  obstacles.push(obstacle); //장애물 객체 생성, 여러개가 계속 생겨야하기 때문
}

function RandomIntInRange(min, max) {
  return Math.round(Math.random() * (max - min) + min); //Math 함수를 통해 random사용
}

function Start() {
  //게임이 시작하면 작동할 함수
  //초기 값 설정
  //공룡을 그려줌
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;

  ctx.font = "20px sans-serif";

  gameSpeed = 3;
  gravity = 1;

  score1 = 0;
  score2 = 0;
  highscore1 = 0;
  highscore2 = 0;

  if (localStorage.getItem("highscore")) {
    highscore = localStorage.getItem("highscore");
  }

  getJSON('http://api.openweathermap.org/data/2.5/weather?q=seoul&appid=d82f8a1442e7f1283352af04e4568c8a&units=metric'
,
function(err,data){
  if(err !== null){
    alert('예상치 못한 오류 발생.' + err);
  } else{
    dinoweather=data.weather[0].description;//날씨 가져옴
  
  alert(`날씨:${data.weather[0].description}`)

  
//날씨에 따라 그림 다르게 하기
switch(dinoweather) 
{case "clear sky":
  dinoimg[0]="dino_clear.png";
  dinoimg[1]="dinodown_clear.png";
  obstacleimg[1]="bug_clear.png";
  obstacleimg[0]="sun_clear.png";//0위 1아래
 break;

case "few clouds":
case "overcast clouds":
case "scattered clouds":
case "broken clouds":
case "mist":
  dinoimg[0]="dino_cloudy.png";
  dinoimg[1]="dinodown_cloudy.png";
  obstacleimg[1]="cloudes_cloudy.png";
  obstacleimg[0]="clouds_cloudy.png";//위
  break;
case "rain":
case "shower rain":
  dinoimg[0]="dino_rainy.png";
  dinoimg[1]="dinodown_rainy.png";
  obstacleimg[0]="rain_rainy.png";//위
  obstacleimg[1]="pool_rainy.png";//아래
    break;
case "thunderstorm":
  dinoimg[0]="dino_stormy.png";
  dinoimg[1]="dinodown_stormy.png";
  obstacleimg[0]="thunder_stormy.png";//위
  obstacleimg[1]="pool_rainy.png";//아래
  break;
case "snow":
  dinoimg[0]="dino_snowy.png";
  dinoimg[1]="dinodown_snowy.png";
  obstacleimg[0]="snow_snowy.png";//위
  obstacleimg[1]="snowman_snowy.png";//아래
  break;
}
  }
});//



dino1 = new Dino(25, canvas.height - 150, 50, 50, "pink", 1);
dino2 = new Dino(75, canvas.height - 150, 50, 50, "blue", 2);

scoreText1 = new Text("Player 1 Score: " + score1, 25, 25, "left", "#000", 20);
scoreText2 = new Text("Player 2 Score: " + score2, 25, 50, "left", "#000", 20);

  highscoreText1 = new Text(
    "Highscore1: " + highscore1,
    canvas.width - 25,
    25,
    "right",
    "#212121",
    "20"
  );

  highscoreText2 = new Text(
    "Highscore2: " + highscore2,
    canvas.width - 25,
    25,
    "right",
    "#212121",
    "20"
  );

  requestAnimationFrame(Update); //추가
}

let initialSpawnTimer = 200; //기본 스폰 타이머
let spawnTimer = initialSpawnTimer;

function Update() {
  //지속적으로 변화를 주기 위해 requestAnimatinoFrame 활용
  //clearRect로 지우고 Draw()로 그리기 반복해서
  //앞으로 나가는 것처럼 보이도록 만들기

  requestAnimationFrame(Update);
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  dino1.Draw();
  dino2.Draw();
  //   dino.x++;
  dino1.Animate();
  dino2.Animate(); //공룡한테 애니메이션 주는 함수 <- 여기서 그려줄거임

  spawnTimer--; //스폰타이머--
  if (spawnTimer <= 0) {
    //장애물 속도 조절하는 if문
    SpawnObstacle(); // 장애물 객체 생성
    console.log(obstacles);
    spawnTimer = initialSpawnTimer - gameSpeed * 8; //점점 스폰되는 간격이 짧아짐

    if (spawnTimer < 60) {
      spawnTimer = 60; //스폰간격의 하한선 결정
    }
  }

  //장애물 생성
  for (let i = 0; i < obstacles.length; i++) {
    let o = obstacles[i];

    if (o.x + o.w < 0) {
      obstacles.splice(i, 1);
    }

    // 충돌 처리
    if (
      (dino1.x < o.x + o.w &&
        dino1.x + dino1.w > o.x &&
        dino1.y < o.y + o.h &&
        dino1.y + dino1.h > o.y) ||
      (dino2.x < o.x + o.w &&
        dino2.x + dino2.w > o.x &&
        dino2.y < o.y + o.h &&
        dino2.y + dino2.h > o.y)
    ) {
      init();
    }

    o.Update();
  }

  score1++;
  score2++;
  scoreText1.t = "Player 1 Score: " + score1;
  scoreText2.t = "Player 2 Score: " + score2;
  scoreText1.Draw();
  scoreText2.Draw();


  if (score1 > highscore1) {
    highscore1 = score1;
    highscoreText1.t = "Highscore: " + highscore1;
  }

  highscoreText1.Draw();

  if (score2 > highscore2) {
    highscore2 = score2;
    highscoreText2.t = "Highscore: " + highscore2;
  }

  highscoreText2.Draw();

  gameSpeed += 0.003;
}
Start();

function init() {
  obstacles = [];
  score = 0;
  spawnTimer = initialSpawnTimer;
  gameSpeed = 3;

  window.localStorage.setItem("highscore", highscore);
}



/*getJSON('http://api.openweathermap.org/data/2.5/weather?q=seoul&appid=d82f8a1442e7f1283352af04e4568c8a&units=metric'
,
function(err,data){
  if(err !== null){
    alert('예상치 못한 오류 발생.' + err);
  } else{
    dinoweather=data.weather[0].description;//날씨 가져옴
    alert(`날씨:${data.weather[0].description}`)
  }
});*/